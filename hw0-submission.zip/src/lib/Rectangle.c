
#include "Rectangle.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

/* Your code here to define the struct */